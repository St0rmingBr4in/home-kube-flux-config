METRIC_MAP = {
    "gotk_reconcile_condition": "gotk.reconcile.condition",
    "gotk_suspend_status": "gotk.suspend.status",
    "gotk_reconcile_duration_seconds": "gotk.reconcile.duration.seconds",
    "controller_runtime_active_workers": "controller.runtime.active.workers",
    "controller_runtime_reconcile": "controller.runtime.reconcile",
    "controller_runtime_reconcile_time_seconds": "controller.runtime.reconcile.time.seconds",
    "controller_runtime_max_concurrent_reconciles": "controller.runtime.max.concurrent.reconciles",
    "controller_runtime_reconcile_errors": "controller.runtime.reconcile.errors",
}
